import os
from flask import Flask, request, jsonify, render_template, session
from transformers import pipeline, AutoModelForQuestionAnswering, AutoTokenizer
import json
import difflib
import re

app = Flask(__name__)
app.secret_key = os.getenv('FLASK_SECRET_KEY', 'default_secret_key')  # Use a secure key

# Load the sample question-answer JSON file
with open("C:\\Users\\HP\\Desktop\\project\\QA json file\\QA.json", 'r') as f:
    faqs = json.load(f)

# Load the pre-trained model and tokenizer
model_name = "distilbert-base-uncased-distilled-squad"
model = AutoModelForQuestionAnswering.from_pretrained(model_name)
tokenizer = AutoTokenizer.from_pretrained(model_name)
qa_pipeline = pipeline("question-answering", model=model, tokenizer=tokenizer)

cache = {}

def count_tokens(text):
    # Tokenize the text and count the tokens
    tokens = tokenizer.encode(text, truncation=True)
    return len(tokens)

def get_cached_response(question):
    return cache.get(question, None)

def set_cached_response(question, answer):
    cache[question] = answer

def get_response(question, faqs):
    questions = [faq['question'] for faq in faqs]
    best_match = difflib.get_close_matches(question, questions, n=1, cutoff=0.75)
    if best_match:
        for faq in faqs:
            if best_match[0] == faq['question']:
                return faq['answer'], best_match[0]
    return None, None

def extract_keywords(text):
    return set(re.findall(r'\b\w+\b', text.lower()))

def handle_special_phrases(user_message):
    user_message = user_message.lower()
    if any(phrase in user_message for phrase in ["hi", "hello", "hey"]):
        return "Hello! How can I assist you today?"
    elif any(phrase in user_message for phrase in ["thank you", "thanks", "thx", "thankyou"]):
        return "You're welcome! If you have any other questions, feel free to ask."
    elif any(phrase in user_message for phrase in ["bye", "quit", "exit", "goodbye"]):
        return "Goodbye! Have a great day!"
    return None

@app.route('/')
def home():
    return render_template('index2.html')

@app.route('/init', methods=['GET'])
def init_chat():
    if 'history' not in session:
        session['history'] = []
        session['keywords'] = []

    welcome_message = "Hi! How can I help you?"
    session['history'].append({'role': 'bot', 'content': welcome_message})
    return jsonify({"message": welcome_message})

@app.route('/chat', methods=['POST'])
def chat():
    if 'history' not in session:
        session['history'] = []
        session['keywords'] = []

    user_message = request.json['message']

    # Handle FAQ responses first
    response, faq_question = get_response(user_message, faqs)
    if response:
        keywords = extract_keywords(response)
        session['keywords'].extend(keywords)
        session['history'].append({'role': 'user', 'content': user_message})
        session['history'].append({'role': 'bot', 'content': response})
        app.logger.debug(f"Session data: {session}")
        return jsonify({"message": response})

    # Handle special phrases next
    special_response = handle_special_phrases(user_message)
    if special_response:
        session['history'].append({'role': 'user', 'content': user_message})
        session['history'].append({'role': 'bot', 'content': special_response})
        app.logger.debug(f"Session data: {session}")
        return jsonify({"message": special_response})

    # Use QA pipeline for other queries
    context = ' '.join([item['content'] for item in session['history'] if item['role'] == 'user'])
    enriched_context = context + ' ' + ' '.join(session['keywords'])
    qa_input = {
        'question': user_message,
        'context': enriched_context
    }

    # Check cache
    cached_answer = get_cached_response(user_message)
    if cached_answer:
        bot_message = cached_answer
    else:
        try:
            token_count = count_tokens(user_message) + count_tokens(enriched_context)
            app.logger.info(f"Token count: {token_count}")

            result = qa_pipeline(qa_input)
            if result['score'] < 0.5:
                bot_message = "I'm not sure about that. Please contact the business directly for more information."
            else:
                bot_message = result['answer']
            set_cached_response(user_message, bot_message)
        except Exception as e:
            bot_message = "I'm having trouble processing that request. Please contact the business directly for more information."
            app.logger.error(f"Error during QA pipeline processing: {e}")

    session['history'].append({'role': 'user', 'content': user_message})
    session['history'].append({'role': 'bot', 'content': bot_message})
    app.logger.debug(f"Session data: {session}")
    return jsonify({"message": bot_message})

if __name__ == '__main__':
    app.run(debug=True)
